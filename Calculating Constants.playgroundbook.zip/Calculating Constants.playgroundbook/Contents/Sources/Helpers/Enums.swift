//
//  Enums.swift
//  Book_Sources
//
//  Created by Bram Roelandts on 3/17/19.
//

import Foundation


public enum Constant: String {
    case pi             = "pi"
    case e              = "e"
    case goldenRatio    = "goldenRatio"
    case sqrt2          = "sqrt2"
    
    func humanReadable() -> String {
        switch self {
        case .pi: return "𝛑"
        case .e: return "e"
        case .goldenRatio: return "Φ"
        case .sqrt2: return "√2"
        }
    }
}
