//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  An auxiliary source file which is part of the book-level auxiliary sources.
//  Provides the implementation of the "always-on" live view.
//

import UIKit
import PlaygroundSupport

@objc(Book_Sources_Page2LiveViewController)
public class Page2LiveViewController: UIViewController, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    
    
    // MARK: - Outlets
    
    let balloon = UIImageView()
    
    // MARK: - Variables

    
    // MARK: - ViewDidLoad
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup balloon
        self.view.addSubview(balloon)
        balloon.translatesAutoresizingMaskIntoConstraints = false
        balloon.leadingAnchor.constraint(equalTo: liveViewSafeAreaGuide.leadingAnchor, constant: 100).isActive = true
        balloon.trailingAnchor.constraint(equalTo: liveViewSafeAreaGuide.trailingAnchor, constant: -100).isActive = true
        balloon.topAnchor.constraint(equalTo: liveViewSafeAreaGuide.topAnchor).isActive = true
        balloon.bottomAnchor.constraint(equalTo: liveViewSafeAreaGuide.bottomAnchor).isActive = true

        // Style balloon
        balloon.contentMode = .scaleAspectFit
        balloon.image = UIImage(named: "Balloons.png")

    }
    
    public func receive(_ message: PlaygroundValue) {
        switch message {
        case let .dictionary(dictionary):
            print(dictionary)
        default: break
        }
    }

}
