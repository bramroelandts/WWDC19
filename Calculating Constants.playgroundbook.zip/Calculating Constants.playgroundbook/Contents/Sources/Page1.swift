//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  An auxiliary source file which is part of the book-level auxiliary sources.
//  Provides the implementation of the "always-on" live view.
//

import UIKit
import PlaygroundSupport
import AVFoundation

@objc(Book_Sources_Page1LiveViewController)
public class Page1LiveViewController: UIViewController, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    
    
    // MARK: - Outlets
    
    let imageView = UIImageView()
    var firstShell: UILabel!
    var secondShell: UILabel!
    var negativeResponse: UILabel!
    
    
    // MARK: - Variables
    var currentLabel: UILabel!
    var currentString: String!
    var currentIndex: Int!
    var typeTimer: Timer?
    private var stage = Stage.start
    
    var playerArray = [AVAudioPlayer]()
    var keyUrl: URL!
    var enterPlayer: AVAudioPlayer?
    
    
    // MARK: - ViewDidLoad
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        // Background image
        self.view.addSubview(imageView)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.leadingAnchor.constraint(equalTo: liveViewSafeAreaGuide.leadingAnchor).isActive = true
        imageView.trailingAnchor.constraint(equalTo: liveViewSafeAreaGuide.trailingAnchor).isActive = true
        imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor).isActive = true
        imageView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor).isActive = true
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "Terminal.png")
        
        // Decide topConstant
        var topConstant: CGFloat = -110
        switch UIScreen.main.bounds.height {
            
        // 9.7 inch iPad Pro
        case 768: topConstant = -65
           
        // 10.5 inch iPad Pro
        case 834: topConstant = -75
        
        // 12.9 inch iPad Pro
        case 1024: topConstant = -110
            
        default: break
        }
        
        // LastLogin
        let lastLogin = UILabel()
        self.view.addSubview(lastLogin)
        lastLogin.translatesAutoresizingMaskIntoConstraints = false
        lastLogin.widthAnchor.constraint(equalTo: liveViewSafeAreaGuide.widthAnchor, multiplier: 640/800).isActive = true
        lastLogin.centerXAnchor.constraint(equalTo: liveViewSafeAreaGuide.centerXAnchor).isActive = true
        lastLogin.centerYAnchor.constraint(equalTo: liveViewSafeAreaGuide.centerYAnchor, constant: topConstant).isActive = true
        lastLogin.font = UIFont(name: "Menlo-Regular", size: 14)
        lastLogin.textColor = .white
        print(UIScreen.main.bounds.height)
        
        // Set current date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "E MMM d HH:mm:ss"
        lastLogin.text = "Last login: " + dateFormatter.string(from: Date()) + " on ttys000"
        
        // FirstShell
        firstShell = UILabel()
        self.view.addSubview(firstShell)
        firstShell.translatesAutoresizingMaskIntoConstraints = false
        firstShell.widthAnchor.constraint(equalTo: liveViewSafeAreaGuide.widthAnchor, multiplier: 640/800).isActive = true
        firstShell.centerXAnchor.constraint(equalTo: liveViewSafeAreaGuide.centerXAnchor).isActive = true
        firstShell.topAnchor.constraint(equalTo: lastLogin.bottomAnchor, constant: 5).isActive = true
        firstShell.font = UIFont(name: "Menlo-Regular", size: 14)
        firstShell.textColor = .white
        firstShell.text = "Brams-iPad-Pro:~ Bram$ "
        
        // Response
        negativeResponse = UILabel()
        self.view.addSubview(negativeResponse)
        negativeResponse.translatesAutoresizingMaskIntoConstraints = false
        negativeResponse.widthAnchor.constraint(equalTo: liveViewSafeAreaGuide.widthAnchor, multiplier: 475/800).isActive = true
        negativeResponse.heightAnchor.constraint(equalToConstant: 30).isActive = true
        negativeResponse.centerXAnchor.constraint(equalTo: liveViewSafeAreaGuide.centerXAnchor).isActive = true
        negativeResponse.topAnchor.constraint(equalTo: firstShell.bottomAnchor, constant: 20).isActive = true
        negativeResponse.font = UIFont(name: "Menlo-Bold", size: 14)
        negativeResponse.textColor = .white
        negativeResponse.textAlignment = .center
        negativeResponse.text = "Fetch unsuccessful. No internet connection."
        negativeResponse.layer.borderColor = UIColor.white.cgColor
        negativeResponse.layer.borderWidth = 1
        negativeResponse.alpha = 0.0
        negativeResponse.adjustsFontSizeToFitWidth = true
        
        // SecondShell
        secondShell = UILabel()
        self.view.addSubview(secondShell)
        secondShell.translatesAutoresizingMaskIntoConstraints = false
        secondShell.widthAnchor.constraint(equalTo: liveViewSafeAreaGuide.widthAnchor, multiplier: 640/800).isActive = true
        secondShell.centerXAnchor.constraint(equalTo: liveViewSafeAreaGuide.centerXAnchor).isActive = true
        secondShell.topAnchor.constraint(equalTo: negativeResponse.bottomAnchor, constant: 20).isActive = true
        secondShell.font = UIFont(name: "Menlo-Regular", size: 14)
        secondShell.textColor = .white
        secondShell.text = "Brams-iPad-Pro:~ Bram$ "
        secondShell.alpha = 0.0
        
        // Setup the players
        keyUrl = Bundle.main.url(forResource: "key", withExtension: "mp3")
        let enterUrl = Bundle.main.url(forResource: "enter", withExtension: "mp3")
        if let url = enterUrl {
            do {
                try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
                try AVAudioSession.sharedInstance().setActive(true)
                self.enterPlayer = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            } catch {}
        }
        
        // Start typing
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            self.typeFirstShell()
        }
    }
    
    public func receive(_ message: PlaygroundValue) {
        switch message {
        case let .dictionary(dictionary):
            print(dictionary)
        default: break
        }
    }
    
    
    // MARK: - Animation
    
    public func typeFirstShell() {
        
        currentLabel = firstShell
        currentString = "swift run FetchPi"
        currentIndex = 0
        stage = .firstTyped
        playerArray = []
        type()
    }
    
    @objc private func type() {
        
        if currentIndex < currentString.count {
            
            // Set the label
            playKeySound()
            currentLabel.text = currentLabel.text! + String(currentString[currentIndex])
            currentIndex += 1
            
            // Set the timer for the next character
            typeTimer?.invalidate()
            let randomInterval = Double((arc4random_uniform(8) + 1)) / 60
            typeTimer = Timer.scheduledTimer(timeInterval: randomInterval, target: self, selector: #selector(self.type), userInfo: nil, repeats: false)
            
        } else {
            
            // We finished
            
            switch stage {
            case .firstTyped:
                
                self.enterPlayer?.play()
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.negativeResponse.alpha = 1.0
                    self.secondShell.alpha = 1.0
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 10.0, execute: {
                        self.currentLabel = self.secondShell
                        self.currentString = "clear"
                        self.currentIndex = 0
                        self.stage = .secondTyped
                        self.type()
                    })
                }
                
            case .secondTyped:
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                    
                    self.enterPlayer?.play()
                    self.firstShell.text = "Brams-iPad-Pro:~ Bram$ "
                    self.secondShell.text = "Brams-iPad-Pro:~ Bram$ "
                    self.negativeResponse.alpha = 0.0
                    self.secondShell.alpha = 0.0
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                        self.typeFirstShell()
                    }
                }
                
            default: break
            }
        }
    }
    
    func playKeySound() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            let audioPlayer = try AVAudioPlayer(contentsOf: self.keyUrl)
            self.playerArray.append(audioPlayer)
            self.playerArray.last?.prepareToPlay()
            self.playerArray.last?.play()
        } catch {}
    }
}

public extension StringProtocol {
    public subscript (i: Int) -> Element {
        return self[index(startIndex, offsetBy: i)]
    }
}

fileprivate enum Stage {
    case start
    case firstTyped
    case responseGiven
    case secondTyped
}
