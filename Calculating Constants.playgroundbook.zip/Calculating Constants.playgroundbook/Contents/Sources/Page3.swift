//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  An auxiliary source file which is part of the book-level auxiliary sources.
//  Provides the implementation of the "always-on" live view.
//

import UIKit
import PlaygroundSupport
import AVFoundation

@objc(Book_Sources_Page3LiveViewController)
public class Page3LiveViewController: UIViewController, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {

    
    // MARK: - Outlets
    
    let label = UILabel()
    let headerLabel = UILabel()
    let imageView = UIImageView()
    let formatter = FixedPointNumberDecimalFormatter()
    let initView = UIView()
    
    
    // MARK: - Variables
    
    var calculatedConstant = ""
    var randomSuffix = ""
    var progressFill: UIView!
    var progressBorder: UIView!
    var player: AVAudioPlayer?
    var constantLabel: UILabel!
    var cursorBlinkTimer: Timer?
    var calculationTimer: Timer?
    var randomizationTimer: Timer?
    
    // MARK: - ViewDidLoad
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        // Background image
        self.view.addSubview(imageView)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.leadingAnchor.constraint(equalTo: liveViewSafeAreaGuide.leadingAnchor).isActive = true
        imageView.trailingAnchor.constraint(equalTo: liveViewSafeAreaGuide.trailingAnchor).isActive = true
        imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor).isActive = true
        imageView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor).isActive = true
        
        
        // Create the headerLabel
        self.view.addSubview(headerLabel)
        headerLabel.translatesAutoresizingMaskIntoConstraints = false
        headerLabel.leadingAnchor.constraint(equalTo: liveViewSafeAreaGuide.leadingAnchor).isActive = true
        headerLabel.trailingAnchor.constraint(equalTo: liveViewSafeAreaGuide.trailingAnchor).isActive = true
        headerLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: (view.frame.height * 0.225)).isActive = true
        
        // Create the label
        self.view.addSubview(label)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.centerXAnchor.constraint(equalTo: liveViewSafeAreaGuide.centerXAnchor).isActive = true
        label.topAnchor.constraint(equalTo: headerLabel.bottomAnchor, constant: 10).isActive = true
        label.heightAnchor.constraint(equalTo: imageView.heightAnchor, multiplier: 175/650).isActive = true
        label.widthAnchor.constraint(equalTo: imageView.heightAnchor, multiplier: 280/650).isActive = true
        
        // Create the init view
        self.view.addSubview(initView)
        initView.translatesAutoresizingMaskIntoConstraints = false
        initView.centerXAnchor.constraint(equalTo: liveViewSafeAreaGuide.centerXAnchor).isActive = true
        initView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: (view.frame.height * 0.27)).isActive = true
        initView.heightAnchor.constraint(equalTo: imageView.heightAnchor, multiplier: 130/650).isActive = true
        initView.widthAnchor.constraint(equalTo: imageView.heightAnchor, multiplier: 190/650).isActive = true
        
        // Load the macOS 7 font
        let fontURL = Bundle.main.url(forResource: "chicagobold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        
        // Style the labels
        label.numberOfLines = 0
        label.font = UIFont(name: "AvenirNext-Medium", size: 18)
        label.adjustsFontSizeToFitWidth = true
        label.textColor = .white
        
        headerLabel.font = UIFont(name: "chicagobold", size: 25)!
        headerLabel.textAlignment = .center
        headerLabel.textColor = .white
        
        // Setup the imageView
        imageView.contentMode = .scaleAspectFill
        imageView.image = UIImage(named: "Macintosh_start.png")

        // Setup the initView
        initView.alpha = 0
        initView.backgroundColor = .white
        initView.layer.cornerRadius = 5.0

        // Create a progress bar border
        let barBorder = UIView()
        initView.addSubview(barBorder)
        barBorder.translatesAutoresizingMaskIntoConstraints = false
        barBorder.heightAnchor.constraint(equalToConstant: 17).isActive = true
        barBorder.centerXAnchor.constraint(equalTo: initView.centerXAnchor).isActive = true
        barBorder.widthAnchor.constraint(equalTo: initView.widthAnchor, multiplier: 0.6).isActive = true
        barBorder.bottomAnchor.constraint(equalTo: initView.bottomAnchor, constant: -30).isActive = true
        barBorder.backgroundColor = .white
        barBorder.layer.borderColor = UIColor.black.cgColor
        barBorder.layer.borderWidth = 2
        
        progressFill = UIView()
        progressFill.backgroundColor = .black
        barBorder.addSubview(progressFill)
        progressBorder = barBorder

        // InitView label
        let initLabel = UILabel()
        initView.addSubview(initLabel)
        initLabel.translatesAutoresizingMaskIntoConstraints = false
        initLabel.leadingAnchor.constraint(equalTo: initView.leadingAnchor).isActive = true
        initLabel.trailingAnchor.constraint(equalTo: initView.trailingAnchor).isActive = true
        initLabel.bottomAnchor.constraint(equalTo: barBorder.topAnchor, constant: -25).isActive = true
        initLabel.heightAnchor.constraint(equalToConstant: 25).isActive = true
        initLabel.text = "Initializing calculation..."
        initLabel.font = UIFont(name: "chicagobold", size: 16)!
        initLabel.textAlignment = .center
        
        // InitView Constant label
        constantLabel = UILabel()
        initView.addSubview(constantLabel)
        constantLabel.translatesAutoresizingMaskIntoConstraints = false
        constantLabel.leadingAnchor.constraint(equalTo: initView.leadingAnchor).isActive = true
        constantLabel.trailingAnchor.constraint(equalTo: initView.trailingAnchor).isActive = true
        constantLabel.topAnchor.constraint(equalTo: initView.topAnchor).isActive = true
        constantLabel.bottomAnchor.constraint(equalTo: initLabel.topAnchor).isActive = true
        constantLabel.textAlignment = .center
        constantLabel.font = UIFont(name: "chicagobold", size: 60)!

        // Debugging
//        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
//            self.startCalculation(constant: .pi, digits: 500)
//            //self.initView.isHidden = true
//        }
    }
    
    public func receive(_ message: PlaygroundValue) {
        switch message {
        case let .dictionary(dictionary):
            
            guard case let .string(constantString)? = dictionary["constant"] else { return }
            guard case let .integer(digits)? = dictionary["digits"] else { return }
            
            let constant = Constant(rawValue: constantString) ?? .pi
            startCalculation(constant: constant, digits: digits)
        default: break
        }
    }
    
    
    // MARK: - Calculation
    
    func startCalculation(constant: Constant, digits: Int) {

        // Reset variables
        self.calculatedConstant = ""
        self.randomSuffix = ""
        self.label.text = ""
        self.headerLabel.text = ""
        self.headerLabel.alpha = 0
        self.cursorBlinkTimer?.invalidate()
        self.calculationTimer?.invalidate()
        self.randomizationTimer?.invalidate()
        
        // If not Pi, limit to 10.000 digits
        var digits = digits
        if digits > 10000 && constant != .pi {
            digits = 10000
        }
        
        // Fetch the actual constant
        fetchActualConstant(constant, digits: digits)
       
        // Boot up the Macintosh
        startInitializationAnimation(constant: constant)
        
        // Start the on-screen calculation animation
        startCalculationAnimation(digits: digits)
    }
    
    func fetchActualConstant(_ constant: Constant, digits: Int) {
        
        DispatchQueue.main.async {
            
            switch constant {
            case .pi:
                self.calculatedConstant = "3.14"
                self.calculatedConstant = self.calculatePi(digits: digits)
                
            case .e:
                self.calculatedConstant = "2.71"
                self.calculatedConstant = String(e.dropLast(10000 - digits))
                
            case .goldenRatio:
                self.calculatedConstant = "1.61"
                self.calculatedConstant = String(goldenRatio.dropLast(10000 - digits))
                
            case .sqrt2:
                self.calculatedConstant = "1.41"
                self.calculatedConstant = String(sqrt2.dropLast(10000 - digits))
            }
        }
    }
    
    func startInitializationAnimation(constant: Constant) {
        
        // Reset the progress bar
        self.progressFill.frame = CGRect(x: 0, y: 0, width: 0, height: self.progressBorder.bounds.height)

        // Set the constant text
        self.constantLabel.text = constant.humanReadable()
        self.headerLabel.text = constant.humanReadable() + " equals"
        
        // Remove the "Hello" label
        UIView.transition(with: self.imageView, duration: 0.5, options: .transitionCrossDissolve, animations: {
            self.imageView.image = UIImage(named: "Macintosh.png")
        }) { (success) in
            
            // Play the startup chime
            let url = Bundle.main.url(forResource: "StartupSound", withExtension: "wav")
            if let url = url {
                do {
                    try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
                    try AVAudioSession.sharedInstance().setActive(true)
                    self.player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
                    self.player?.volume = 0.65
                    self.player?.play()
                } catch {}
            }
            
            // Animate the popup in
            UIView.animate(withDuration: 0.2, animations: {
                self.initView.alpha = 1.0
            }, completion: { (success) in
                
                // Animate the progress bar
                UIView.animate(withDuration: 2.5, delay: 1.3, options: .curveEaseOut, animations: {
                    self.progressFill.frame = CGRect(x: 0, y: 0, width: self.progressBorder.bounds.width, height: self.progressBorder.bounds.height)
                }, completion: { (success) in
                    
                    // Animate the popup out
                    UIView.animate(withDuration: 0.4, delay: 1.0, animations: {
                        self.initView.alpha = 0
                    }, completion: { (success) in
                    
                        UIView.animate(withDuration: 0.4, delay: 0.8, animations: {
                            self.headerLabel.alpha = 1.0
                        })
                    })
                })
            })
        }
    }
    
    func startCalculationAnimation(digits: Int) {
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 7) {
            
            var index = 3
            
            // Generate a random suffix to get started
            self.randomSuffix = self.randomString(length: digits)

            // Periodically generate random strings
            self.randomizationTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true, block: { (timer) in
                self.randomSuffix = self.randomString(length: digits)
                if index > digits {
                    timer.invalidate()
                }
            })

            // This function allocates 5 seconds for 100 digits, 12 for 1,000 digits and 20 for 5,000
            let doubleDigits = Double(digits)
            let totalTime = -0.000001179*doubleDigits*doubleDigits+0.009075*doubleDigits+4.104
            let interval = abs(totalTime) / Double(digits)
            
            // Periodically release more actual digits
            self.calculationTimer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true, block: { (timer) in
                var actualDigits = self.calculatedConstant
                if actualDigits.count > 4 {
                    actualDigits = String(actualDigits.dropLast(max((digits - index), 0)))
                }
                
                // Format string
                var resultString = actualDigits + String(self.randomSuffix.dropFirst(index))
                var range: NSRange!
                
                // Add a space on the last pass
                if index > digits {
                    resultString.append("   ")
                    range = NSRange(resultString.index(resultString.endIndex, offsetBy: -2)..<resultString.endIndex, in: resultString)
                } else {
                    range = NSRange(resultString.index(resultString.startIndex, offsetBy: index)..<resultString.index(resultString.startIndex, offsetBy: index + 1), in: resultString)
                }
                
                // Highlight certain parts
                let mutable = NSMutableAttributedString(string: resultString)
                mutable.addAttribute(.backgroundColor, value: UIColor(red:0.18, green:0.80, blue:0.44, alpha:1.0), range: range)
                self.label.attributedText = mutable
                
                
                if index > digits {
                    timer.invalidate()
                    self.startCursorBlinkAnimation()
                }
                index += 1
            })
        }
    }
    
    func startCursorBlinkAnimation() {
        
        var blinkOn = true
        
        cursorBlinkTimer = Timer.scheduledTimer(withTimeInterval: 0.530, repeats: true, block: { (timer) in
            
            let string = self.label.attributedText?.string ?? ""
            let mutable = NSMutableAttributedString(string: string)
            let range = NSRange(string.index(string.endIndex, offsetBy: -2)..<string.endIndex, in: string)
            let color = blinkOn ? UIColor.clear : UIColor(red:0.18, green:0.80, blue:0.44, alpha:1.0)
            mutable.addAttribute(.backgroundColor, value: color, range: range)
            self.label.attributedText = mutable
            
            blinkOn = !blinkOn
        })
    }
    
    
    // MARK: - Pi calculation
    
    func calculatePi(digits: Int) -> String {
        
        // Regular Pi calculation using Taylor series
        //
        // tan(pi/4) = 1
        //   pi = 4.bgtan(1)
        //   pi = 4( 1 - 1/3 + 1/5 - 1/7 + ...)
        
        // Algorithm used in this implementation
        //
        // pi = 16.arctan(1/5) - 4 arctan(1/239)
        
        
        // Calculate constants
        let arctan5 = self.taylorArctan(denominator: 5, digits: digits)
        let arctan239 = self.taylorArctan(denominator: 239, digits: digits)
        
        // pi = 4(4.arctan(1/5) - arctan(1/239))
        arctan5 *= 4
        arctan5 -= arctan239
        arctan5 *= 4
        
        // Format FixedPointNumber to string
        let result = self.formatter.toString(number: arctan5)
        return result
    }
    
    func taylorArctan(denominator: UInt32, digits: Int) -> FixedPointNumber {
        let taylorResult = FixedPointNumber(decimalPlaces: digits)
        let sequence = ArctanTaylorFixedPointNumberSequence(unitFractionDenominator: denominator, decimalPlaces: digits)
        for term in sequence {
            if (term.isPositive) {
                taylorResult += term
            } else {
                taylorResult -= term
            }
        }
        return taylorResult
    }
    
    
    // MARK: - Helpers
    
    func randomString(length: Int) -> String {
        let letters = "0123456789"
        return String((0...length-1).map{ _ in letters.randomElement()!})
    }
}
