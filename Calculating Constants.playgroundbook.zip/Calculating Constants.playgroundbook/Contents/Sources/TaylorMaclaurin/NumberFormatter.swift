//
//  NumberFormatter.swift
//  Book_Sources
//
//  Created by Bram Roelandts on 2/19/19.
//

import Foundation

class FixedPointNumberDecimalFormatter {
    
    
    // MARK: - Variables
    
    var roundup = true
    var removeTrailingZeros = true
    
    
    // MARK: - Functions
    
    func toString(number: FixedPointNumber) -> String {
        let tempNumber = number.copy()
        var index = 0
        var digits = [UInt32]()
        
        while index <= tempNumber.decimalPlaces {
            tempNumber.parts[0] = 0
            tempNumber *= 10
            digits.append(tempNumber.integerPart())
            index += 1
        }
        
        var preRadix = number.integerPart()
        if roundupDigits(digits: &digits) {
            preRadix += 1
        }
        
        removeTrailingZeros(digits: &digits)
        
        var result = tempNumber.isPositive ? "" : "-"
        
        result += String(preRadix)
        result += "."
        
        for digit in digits {
            result += String(digit)
        }
        
        return result
    }
    
    func roundupDigits(digits: inout [UInt32]) -> Bool {
        
        if !roundup || (digits.count < 2) || ((digits.last ?? 0) < 6) {
            digits.removeLast()
            return false
        }
        
        var index = digits.count - 2
        digits[index] = digits[index] + 1
        
        while (index > 0) && (digits[index] > 9) {
            digits[index] = 0
            digits[index - 1] = digits[index - 1] + 1
            index -= 1
        }
        
        digits.removeLast()
        
        if digits[0] > 9 {
            // Did overflow
            digits[0] = 0
            return true
        }
        
        return false
    }
    
    func removeTrailingZeros(digits: inout [UInt32]) {
        if removeTrailingZeros && (digits.count > 1) && (digits.last == 0) {
            digits.removeLast()
            removeTrailingZeros(digits: &digits)
        }
    }
}
