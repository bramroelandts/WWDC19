//
//  ArctanTaylorSequence.swift
//  Book_Sources
//
//  Created by Bram Roelandts on 2/19/19.
//

import Foundation


struct ArctanTaylorFixedPointNumberSequence: Sequence, IteratorProtocol {
    
    let denominator: UInt32
    let decimalPlaces: Int
    var index: UInt32 = 1
    var positiveSign = false;
    
    var x: FixedPointNumber
    var xDivisor: UInt32
    

    init(unitFractionDenominator: UInt32, decimalPlaces: Int)
    {
        denominator = unitFractionDenominator
        self.decimalPlaces = decimalPlaces
    
        x = FixedPointNumber(numerator: 1, denominator: denominator, decimalPlaces: decimalPlaces)
        xDivisor = unitFractionDenominator * unitFractionDenominator
    }
    
    mutating func next() -> FixedPointNumber? {
        
        let term = FixedPointNumber(fixedPointNumber: x)
        term /= index
        
        positiveSign = !positiveSign
        index += 2
        
        x /= xDivisor
        term.isPositive = positiveSign

        return term.isZero() ? nil : term
    }
}
