/*:
 # Only the right tools get the job done 🛠
 \
 **Floating point numbers** typically only offer *18 digits* of precision.
 Our goal however is to calculate constants to thousands of digits in **pure Swift**.
 
 * callout(Our solution):
 To properly store these long numbers, we'll need to hack a **new data type** on top of `Swift`. 🏴‍☠️
 */
//#-hidden-code
import UIKit
import PlaygroundSupport
class SomeNewDataType {}
//#-end-hidden-code
let number: CGFloat
let longNumber: SomeNewDataType?

/*:
 * callout(Introducting ExtendedFloats):
 `ExtendedFloats` have an infinite amount of digits and are stored as a combination of *binary fractions* in unsigned 32 bit integers.
 */

class ExtendedFloat {
    var parts: [UInt32]
    let decimalPlaces: Int
    // /*#-editable-code*/ [...] /*#-end-editable-code*/
    //#-hidden-code
    var isPositive = true
    var roundup = true
    init(integerPart: UInt32, decimalPlaces: Int) {
        self.parts = []
        self.decimalPlaces = 0
    }
    func leftmostNonZeroPartIndex() -> Int {
        return 0
    }
    //#-end-hidden-code
}

/*:
 * callout(Working with ExtendedFloats):
 To be able to calculate Pi and other constants, we need a way to perform *arithmetic operations* on our new type! ✖️➖
*/

// Arithmetic method using bitwise operations
func *= (number: ExtendedFloat, multiplier: UInt32) {
    var index = number.leftmostNonZeroPartIndex()
    var carry: UInt32 = 0
    while index >= 0 {
        let result64 = (UInt64(number.parts[index]) * UInt64(multiplier)) + UInt64(carry)
        number.parts[index] = UInt32(result64 & 0xFFFFFFFF)
        carry = UInt32(result64 >> 32)
        index -= 1
    }
}

//: And voila! We made our very own contribution to `Swift`. 🎉 \
//: Let's [continue](@next) by actually calculating 𝛑!
