/*:
 # Finding a formula for Pi 🕵🏼‍♂️
 * callout(Deriving a formula using some trigonometric creativity):
 tan(𝛑/4) = 1 \
 𝛑 = 4.arctan(1) \
 𝛑 = 16.arctan(1/5) - 4.arctan(1/239)
 
 \
 Taylor series allow computers to easily approach `arctan(x)`. 🤓
 * callout(Arctan Taylor series):
 arctan(x) = x - x³/3 + x⁵/5 - x⁷/7 + ...
 */
//#-hidden-code

import UIKit
import PlaygroundSupport

// MARK: - Supporting enums
public var pi = Constant.pi
public var e = Constant.e
public var goldenRatio = Constant.goldenRatio
public var sqrt2 = Constant.sqrt2

//#-code-completion(everything, hide)
//#-code-completion(identifier, show, pi, e, goldenRatio, sqrt2)


// MARK: - Mocking
public func taylorArctan(_ constant: Double, _ digits: Int) -> Int { return 0 }
public class Formatter {
    func convertToString(_ number: Int) -> String {return ""}
}
public var formatter = Formatter()

// MARK: - Messaging

public func send(_ dictionary: [String: PlaygroundValue]) {
    let page = PlaygroundPage.current
    if let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy {
        proxy.send(.dictionary(dictionary))
    }
}

public func calculate(_ constant: Constant, digits: Int) {
    send(["constant": .string(constant.rawValue), "digits": .integer(digits)])
}
//#-end-hidden-code


// Choose a constant and play around with digits
// Hit "Run My Code" to see the calculation in action

public func macintoshDidBoot() {
    calculate(/*#-editable-code*/<#T##Constant##Constant#>/*#-end-editable-code*/, digits: /*#-editable-code*/500/*#-end-editable-code*/)
}

//#-hidden-code
macintoshDidBoot()
//#-end-hidden-code
//: And thanks to our awesome tools, calculating Pi and others is a breeze. 😎
