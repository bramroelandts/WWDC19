/*:
 # Mathematical constants 📚

 Everything from circular motion (**𝛑**), to compound interest and decay (**e**), to financial technical analysis (**golden ratio**) heavily relies on *mathematical constants*. Precisely knowing these constants is of big importance. \
 \
 **Let's take a look at them 👀**
 */
//#-hidden-code
import UIKit
import PlaygroundSupport
//#-end-hidden-code

// Fetch Pi from the web
let string = "https://pi.delivery/digits?=" + /*#-editable-code*/"500"/*#-end-editable-code*/
let url = URL(string: string)!
_ = URLSession.shared.dataTask(with: url) {(pi,_,_) in
    print(pi)
}

/*:
 ## Oops, that won't work 🤭
 
 * callout(WWDC19 submission guidelines):
 Your Swift playground should not rely on a network connection.
 
 \
 No worries, [let's calculate](@next) Pi on-device then! 💪🏼
*/
